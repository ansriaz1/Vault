const saveBtn = document.getElementById('save');
const searchInput = document.getElementById('search');

function displayDocs(filter = "") {
    chrome.storage.local.get(['docs', 'isPro'], (data) => {
        const docs = data.docs || [];
        const isPro = data.isPro || false;
        const list = document.getElementById('list');
        list.innerHTML = "";

        docs.filter(d => d.title.toLowerCase().includes(filter.toLowerCase()) || d.category.toLowerCase().includes(filter.toLowerCase())).forEach(d => {
            let item = document.createElement('div');
            item.className = "item";
            item.innerHTML = `<span class="tag">${d.category}</span> <b>${d.title}</b><br><a href="${d.link}" target="_blank">Open Link</a>`;
            list.appendChild(item);
        });

        if (!isPro && docs.length >= 5) {
            saveBtn.disabled = true;
            document.getElementById('lock').style.display = 'block';
        }
    });
}

saveBtn.onclick = () => {
    const title = document.getElementById('docTitle').value;
    const link = document.getElementById('docLink').value;
    const category = document.getElementById('docCategory').value;

    if(!title || !link) return alert("Fill all fields!");

    chrome.storage.local.get(['docs'], (data) => {
        let docs = data.docs || [];
        docs.push({title, link, category});
        chrome.storage.local.set({docs}, () => {
            displayDocs();
            document.getElementById('docTitle').value = "";
            document.getElementById('docLink').value = "";
        });
    });
};

searchInput.oninput = () => displayDocs(searchInput.value);
displayDocs();
